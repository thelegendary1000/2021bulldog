

const menuBtn = document.querySelector('.burger');
const logo = document.querySelector('.logo')
const navLinks = document.querySelector('.nav-links2');
const navLists = document.querySelectorAll('.nav-links2 li')
const searchBtn = document.querySelector('.search-btn')
let searchBar = document.querySelector('.search-bar')
let clickBtn = document.querySelector('.exit-btn')

let menuOpen = false;
let searchOpen= false;


menuBtn.addEventListener('click', () => {
  if(!menuOpen) {
    //add class
    menuBtn.classList.add('open');
    menuOpen = true;
    //toggle nav
    navLinks.classList.toggle('nav-active');  
    console.log('clicked');
    console.log(navLists)
      //animate links
    for (let i = 0; i < navLists.length; ++ i) {
      easeIn(navLists[i], i * 100);
    }
  } else {
    menuBtn.classList.remove('open');
    menuOpen = false;
    navLinks.classList.remove('nav-active')
    navLists.forEach((link, index) => {
      link.classList.remove('link-open')
    })
    console.log('clicked1')
  }

})
searchBtn.addEventListener('click', () => {
 
    logo.style.display = "none"
    searchBtn.style.display = "none"
    menuBtn.style.display ='none';
    searchBar.style.display = "flex";
    clickBtn.style.display = 'flex';
    menuBtn.style.display ='none';
    searchOpen = true;


console.log('clicked')
})
clickBtn.addEventListener ('click', () => {
  console.log('clicked')
  logo.style.display = 'block';
  searchBtn.style.display = 'block';
  menuBtn.style.display = 'block';
  clickBtn.style.display = 'none';
  searchBar.style.display = 'none';
 
})




function easeIn (item, delay) {
  setTimeout(() => {
    item.classList.toggle('link-open')
  }, delay)
}
